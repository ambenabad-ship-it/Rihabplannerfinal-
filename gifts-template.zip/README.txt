GIFT IMAGES — Rihab paliers (14 tiers)
=======================================

How the app maps files to prizes:
  - Folder per palier:  bundle_01/, bundle_02/, ..., bundle_14/
  - Filenames inside start with the tier:
      C1*  -> photo for Prize 1
      C2*  -> photo for Prize 2
      C3*  -> photo for Prize 3
  - Multi-item prizes use a suffix letter (C3a, C3b, C3c ...).
  - Anything after the tier prefix is free text.

Each bundle folder below has a _files_needed.txt listing exactly what
to put. Replace the .txt with real .jpg/.png files following the
suggested names (or any names that start with the right Cx prefix).
When done, upload the whole folder via Data Sources -> Gift Images.
